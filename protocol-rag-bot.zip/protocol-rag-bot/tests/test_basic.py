import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from chunk_and_index import split_into_chunks  # noqa: E402
from log_generator import generate, make_line  # noqa: E402
from log_parser import parse_line, summarize  # noqa: E402


def test_chunking_splits_on_headers():
    text = "# Title\nSome intro text.\n## Section A\nContent A.\n## Section B\nContent B."
    chunks = split_into_chunks(text, "test.md")
    assert len(chunks) >= 2
    assert any("Section A" in c["text"] for c in chunks)
    assert any("Section B" in c["text"] for c in chunks)


def test_chunking_splits_long_sections():
    long_text = "# Title\n" + " ".join(["word"] * 300)
    chunks = split_into_chunks(long_text, "test.md")
    assert len(chunks) > 1


def test_log_generation_is_deterministic_with_seed():
    a = generate(50, seed=1)
    b = generate(50, seed=1)
    assert a == b


def test_log_line_round_trips_through_parser():
    line = make_line(1_700_000_000.123456, "client-0001")
    parsed = parse_line(line)
    assert parsed is not None
    assert parsed["client"] == "client-0001"
    assert parsed["ts"] == 1_700_000_000.123456


def test_summarize_counts_errors():
    lines = generate(500, seed=7)
    records = [parse_line(l) for l in lines]
    records = [r for r in records if r]
    summary = summarize(records)
    assert summary["total_lines"] == len(records)
    assert summary["error_count"] <= summary["total_lines"]


if __name__ == "__main__":
    test_chunking_splits_on_headers()
    test_chunking_splits_long_sections()
    test_log_generation_is_deterministic_with_seed()
    test_log_line_round_trips_through_parser()
    test_summarize_counts_errors()
    print("All tests passed.")
