"""
Parses the synthetic protocol log into structured, queryable records and
reports basic stats (error rate, packet-type breakdown, errors by client).

Design choices for speed:
  - Single regex compiled once, applied per line (no per-field regexes).
  - No per-line object overhead beyond a plain dict.
  - Streams the file line-by-line rather than loading it fully into memory
    twice, so it scales to logs far larger than the sample here.
"""

import argparse
import re
import time
from collections import Counter
from pathlib import Path

LOG_PATH = Path(__file__).parent.parent / "data" / "sample_logs.log"

LINE_RE = re.compile(
    r"^(?P<ts>\d+\.\d+)\s+(?P<level>\w+)\s+client=(?P<client>\S+)\s+"
    r"pkt=(?P<pkt>\S+)\s+(?P<detail>.*)$"
)


def parse_line(line: str):
    m = LINE_RE.match(line)
    if not m:
        return None
    d = m.groupdict()
    d["ts"] = float(d["ts"])
    return d


def parse_file(path: Path):
    records = []
    with open(path, encoding="utf-8") as f:
        for line in f:
            rec = parse_line(line)
            if rec:
                records.append(rec)
    return records


def summarize(records):
    total = len(records)
    errors = [r for r in records if r["level"] == "ERROR"]
    by_pkt = Counter(r["pkt"] for r in records)
    errors_by_client = Counter(r["client"] for r in errors)

    return {
        "total_lines": total,
        "error_count": len(errors),
        "error_rate_pct": round(100 * len(errors) / total, 2) if total else 0,
        "packet_type_breakdown": dict(by_pkt.most_common()),
        "top_error_clients": errors_by_client.most_common(5),
    }


def main():
    parser = argparse.ArgumentParser(description="Parse and summarize a protocol test log.")
    parser.add_argument("--path", type=Path, default=LOG_PATH)
    args = parser.parse_args()

    if not args.path.exists():
        print(f"No log file at {args.path}. Run src/log_generator.py first.")
        return

    start = time.perf_counter()
    records = parse_file(args.path)
    elapsed = time.perf_counter() - start

    summary = summarize(records)

    print(f"\nParsed {summary['total_lines']:,} lines in {elapsed:.4f}s "
          f"({summary['total_lines'] / elapsed:,.0f} lines/sec)\n")
    print(f"Errors: {summary['error_count']:,} ({summary['error_rate_pct']}%)\n")
    print("Packet type breakdown:")
    for pkt, count in summary["packet_type_breakdown"].items():
        print(f"  {pkt:12s} {count:>7,}")
    print("\nTop clients by error count:")
    for client, count in summary["top_error_clients"]:
        print(f"  {client:14s} {count:>4,} errors")
    print()


if __name__ == "__main__":
    main()
