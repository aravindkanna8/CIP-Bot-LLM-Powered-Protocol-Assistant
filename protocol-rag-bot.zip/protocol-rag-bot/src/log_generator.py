"""
Generates a synthetic protocol test log so the decoder has something
realistic — but entirely non-proprietary — to run against. Every line is
fabricated by this script; nothing here is copied from any real system's
logs.
"""

import argparse
import random
from pathlib import Path

PACKET_TYPES = ["CONNECT", "CONNACK", "PUBLISH", "PUBACK", "PUBREC", "PUBREL",
                "PUBCOMP", "SUBSCRIBE", "SUBACK", "UNSUBSCRIBE", "UNSUBACK",
                "PINGREQ", "PINGRESP", "DISCONNECT"]
REASON_CODES = {
    "success": [0x00, 0x01],
    "error": [0x80, 0x81, 0x82, 0x87, 0x90, 0x93, 0x97],
}
TOPICS = ["sensors/room1/temperature", "sensors/room2/humidity",
          "factory/line3/status", "factory/line3/alarm", "fleet/truck42/gps"]
CLIENT_IDS = [f"client-{i:04d}" for i in range(1, 51)]

OUT_PATH = Path(__file__).parent.parent / "data" / "sample_logs.log"


def make_line(ts: float, client_id: str) -> str:
    pkt = random.choice(PACKET_TYPES)
    is_error = random.random() < 0.08
    level = "ERROR" if is_error else "INFO"

    if pkt in ("CONNACK", "PUBACK", "SUBACK", "DISCONNECT"):
        code_pool = REASON_CODES["error"] if is_error else REASON_CODES["success"]
        code = random.choice(code_pool)
        detail = f"reason_code=0x{code:02X}"
    elif pkt == "PUBLISH":
        topic = random.choice(TOPICS)
        qos = random.choice([0, 1, 2])
        retained = random.random() < 0.1
        detail = f"topic={topic} qos={qos} retained={retained} payload_bytes={random.randint(8, 512)}"
    elif pkt == "SUBSCRIBE":
        topic = random.choice(TOPICS)
        detail = f"filter={topic} requested_qos={random.choice([0,1,2])}"
    else:
        detail = f"packet_id={random.randint(1, 65535)}"

    return f"{ts:.6f} {level:5s} client={client_id} pkt={pkt:11s} {detail}"


def generate(num_lines: int, seed: int = 42):
    random.seed(seed)
    ts = 1_700_000_000.0
    lines = []
    for _ in range(num_lines):
        ts += random.uniform(0.0001, 0.05)
        client_id = random.choice(CLIENT_IDS)
        lines.append(make_line(ts, client_id))
    return lines


def main():
    parser = argparse.ArgumentParser(description="Generate a synthetic protocol test log.")
    parser.add_argument("--lines", type=int, default=60_000)
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()

    lines = generate(args.lines, seed=args.seed)
    OUT_PATH.parent.mkdir(parents=True, exist_ok=True)
    OUT_PATH.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"Wrote {len(lines):,} synthetic log lines -> {OUT_PATH}")


if __name__ == "__main__":
    main()
