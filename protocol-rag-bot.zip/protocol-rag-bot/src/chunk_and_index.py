"""
Chunks the markdown spec docs in data/spec_docs/ into retrieval-sized
passages and builds a TF-IDF index over them.

Why TF-IDF instead of a neural embedding model? This repo is meant to be
runnable instantly with no GPU, no model download, and no API key — TF-IDF
+ cosine similarity is a legitimate, classic retrieval baseline and keeps
the demo fully offline. Swapping in a sentence-transformer or an OpenAI/
Anthropic embedding call is a drop-in change in `embed_chunks()` below if
you want higher retrieval quality later.
"""

import json
import pickle
import re
from pathlib import Path

from sklearn.feature_extraction.text import TfidfVectorizer

DATA_DIR = Path(__file__).parent.parent / "data" / "spec_docs"
INDEX_DIR = Path(__file__).parent.parent / "data" / "index"
CHUNK_SIZE_WORDS = 80
CHUNK_OVERLAP_WORDS = 15


def load_documents():
    docs = []
    for path in sorted(DATA_DIR.glob("*.md")):
        text = path.read_text(encoding="utf-8")
        docs.append({"source": path.name, "text": text})
    return docs


def split_into_chunks(text: str, source: str):
    """
    Splits on markdown headers first (so a chunk never straddles two
    unrelated sections), then sub-splits any still-oversized section into
    overlapping word-windows. Preserving section boundaries like this is
    the single biggest lever for retrieval quality — see the README.
    """
    sections = re.split(r"\n(?=#{1,3} )", text)
    chunks = []
    for section in sections:
        section = section.strip()
        if not section:
            continue
        words = section.split()
        if len(words) <= CHUNK_SIZE_WORDS:
            chunks.append(section)
            continue
        start = 0
        while start < len(words):
            end = start + CHUNK_SIZE_WORDS
            chunks.append(" ".join(words[start:end]))
            start += CHUNK_SIZE_WORDS - CHUNK_OVERLAP_WORDS
    return [{"source": source, "text": c} for c in chunks]


def build_index():
    docs = load_documents()
    all_chunks = []
    for doc in docs:
        all_chunks.extend(split_into_chunks(doc["text"], doc["source"]))

    texts = [c["text"] for c in all_chunks]
    vectorizer = TfidfVectorizer(stop_words="english", ngram_range=(1, 2))
    matrix = vectorizer.fit_transform(texts)

    INDEX_DIR.mkdir(parents=True, exist_ok=True)
    with open(INDEX_DIR / "vectorizer.pkl", "wb") as f:
        pickle.dump(vectorizer, f)
    with open(INDEX_DIR / "matrix.pkl", "wb") as f:
        pickle.dump(matrix, f)
    with open(INDEX_DIR / "chunks.json", "w", encoding="utf-8") as f:
        json.dump(all_chunks, f, indent=2)

    print(f"Indexed {len(all_chunks)} chunks from {len(docs)} source docs -> {INDEX_DIR}")
    return len(all_chunks)


if __name__ == "__main__":
    build_index()
