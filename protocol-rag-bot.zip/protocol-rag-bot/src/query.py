"""
Spec-grounded Q&A.

Retrieval is always local (TF-IDF + cosine similarity, built in
chunk_and_index.py). Generation is optional:

  - If ANTHROPIC_API_KEY is set, the top-k retrieved chunks are passed to
    Claude as grounding context and it writes a natural-language answer.
  - If no key is set, the tool runs in "extractive" mode: it just returns
    the top-k most relevant chunks verbatim, ranked by similarity. This
    keeps the whole project runnable by anyone with zero API keys.

Usage:
    python src/query.py "What happens if a broker doesn't get a PINGREQ in time?"
    python src/query.py "What happens if a broker doesn't get a PINGREQ in time?" --k 5
"""

import argparse
import json
import os
import pickle
from pathlib import Path

from sklearn.metrics.pairwise import cosine_similarity

INDEX_DIR = Path(__file__).parent.parent / "data" / "index"


def load_index():
    with open(INDEX_DIR / "vectorizer.pkl", "rb") as f:
        vectorizer = pickle.load(f)
    with open(INDEX_DIR / "matrix.pkl", "rb") as f:
        matrix = pickle.load(f)
    with open(INDEX_DIR / "chunks.json", encoding="utf-8") as f:
        chunks = json.load(f)
    return vectorizer, matrix, chunks


def retrieve(question: str, k: int = 3):
    vectorizer, matrix, chunks = load_index()
    q_vec = vectorizer.transform([question])
    scores = cosine_similarity(q_vec, matrix).flatten()
    top_idx = scores.argsort()[::-1][:k]
    return [
        {"score": float(scores[i]), "source": chunks[i]["source"], "text": chunks[i]["text"]}
        for i in top_idx
    ]


def generate_answer(question: str, retrieved: list):
    """Optional grounded-generation step using the Anthropic API, if a key is present."""
    api_key = os.environ.get("ANTHROPIC_API_KEY")
    if not api_key:
        return None

    import urllib.request

    context = "\n\n---\n\n".join(
        f"[Source: {r['source']}]\n{r['text']}" for r in retrieved
    )
    prompt = (
        "Answer the question using ONLY the context below. If the context "
        "doesn't contain the answer, say so explicitly — do not guess.\n\n"
        f"Context:\n{context}\n\nQuestion: {question}"
    )
    body = json.dumps(
        {
            "model": "claude-sonnet-4-6",
            "max_tokens": 400,
            "messages": [{"role": "user", "content": prompt}],
        }
    ).encode()
    req = urllib.request.Request(
        "https://api.anthropic.com/v1/messages",
        data=body,
        headers={
            "Content-Type": "application/json",
            "x-api-key": api_key,
            "anthropic-version": "2023-06-01",
        },
    )
    with urllib.request.urlopen(req, timeout=30) as resp:
        data = json.loads(resp.read())
    return "".join(block.get("text", "") for block in data.get("content", []))


def main():
    parser = argparse.ArgumentParser(description="Spec-grounded Q&A over the protocol docs.")
    parser.add_argument("question", type=str)
    parser.add_argument("--k", type=int, default=3, help="number of chunks to retrieve")
    args = parser.parse_args()

    retrieved = retrieve(args.question, k=args.k)

    print(f"\nQuestion: {args.question}\n")
    print(f"Retrieved {len(retrieved)} chunks:\n")
    for r in retrieved:
        print(f"  [{r['score']:.3f}] {r['source']}")

    answer = generate_answer(args.question, retrieved)
    print("\n" + "=" * 60)
    if answer:
        print("GROUNDED ANSWER (LLM-generated, grounded in retrieval):\n")
        print(answer)
    else:
        print("EXTRACTIVE MODE (no ANTHROPIC_API_KEY set — showing raw top chunk):\n")
        print(retrieved[0]["text"])
    print("=" * 60 + "\n")


if __name__ == "__main__":
    main()
