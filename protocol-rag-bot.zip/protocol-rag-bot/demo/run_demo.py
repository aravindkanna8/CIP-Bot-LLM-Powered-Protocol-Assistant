"""
End-to-end demo: builds the index, runs three sample questions through
spec-grounded retrieval, generates a synthetic log, and parses it with
timing. Run this from the repo root:

    python demo/run_demo.py

Record your terminal running this (asciinema, or a screen-recording
turned into a GIF) for the README demo section.
"""

import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).parent.parent

SAMPLE_QUESTIONS = [
    "What's the difference between QoS 1 and QoS 2?",
    "What does the multi-level wildcard match?",
    "What happens to session state when Clean Start is set?",
]


def run(cmd):
    print(f"\n$ {' '.join(cmd)}")
    subprocess.run(cmd, cwd=ROOT, check=True)


def main():
    py = sys.executable

    print("=" * 70)
    print("STEP 1 — Build the spec index")
    print("=" * 70)
    run([py, "src/chunk_and_index.py"])

    print("\n" + "=" * 70)
    print("STEP 2 — Ask spec-grounded questions")
    print("=" * 70)
    for q in SAMPLE_QUESTIONS:
        run([py, "src/query.py", q])

    print("\n" + "=" * 70)
    print("STEP 3 — Generate a synthetic test log")
    print("=" * 70)
    run([py, "src/log_generator.py", "--lines", "60000"])

    print("\n" + "=" * 70)
    print("STEP 4 — Parse the log and report timing + stats")
    print("=" * 70)
    run([py, "src/log_parser.py"])

    print("\nDemo complete.")


if __name__ == "__main__":
    main()
