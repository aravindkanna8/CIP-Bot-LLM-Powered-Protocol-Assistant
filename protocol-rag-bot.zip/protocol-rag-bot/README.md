# Protocol Spec RAG Bot

A spec-grounded Q&A system + high-speed log decoder for a network protocol, built entirely on **public data** — a clean-room recreation of the retrieval pattern behind an internal tool I built at Cisco's HackAIthon (CIP Bot), rebuilt here with public MQTT protocol documentation and synthetic logs so the full pipeline is runnable, inspectable, and shareable.

> If you're looking for the write-up of the original internal project (which used proprietary Cisco specs, test infrastructure, and router/switch access), see [`CIP_BOT_CASE_STUDY.md`](./CIP_BOT_CASE_STUDY.md) in this repo.

## What this does

1. **Spec-grounded Q&A** — ask a natural-language question about the MQTT protocol (session handling, QoS levels, topic wildcards, reason codes) and get an answer traceable back to the exact source passage, not a hallucinated summary.
2. **Fast log decoding** — parses large synthetic protocol test logs and reports packet-type breakdowns, error rates, and the noisiest clients, fast enough to use interactively rather than as a batch job.

Both pieces mirror the architecture of the original internal tool; only the data is different.

## Quickstart

```bash
git clone <this-repo>
cd protocol-rag-bot
pip install -r requirements.txt

# 1. Build the retrieval index from the spec docs
python src/chunk_and_index.py

# 2. Ask it something
python src/query.py "What's the difference between QoS 1 and QoS 2?"

# 3. Generate a synthetic test log and decode it
python src/log_generator.py --lines 60000
python src/log_parser.py

# Or run all of the above end-to-end:
python demo/run_demo.py
```

No API key required by default — retrieval runs fully offline. If you set `ANTHROPIC_API_KEY`, `query.py` will additionally generate a natural-language answer grounded in the retrieved chunks; without it, the tool runs in extractive mode and returns the top-ranked passage directly.

## Architecture

```
Question (CLI)
      │
      ▼
TF-IDF query vector
      │
      ▼
Cosine similarity search ──► Top-k relevant spec chunks (data/index/)
      │
      ▼
[optional] LLM generates grounded answer, or extractive mode returns top chunk

Synthetic log (data/sample_logs.log)
      │
      ▼
Single-pass regex parser ──► Structured records
      │
      ▼
Summary: packet-type breakdown, error rate, noisiest clients
```

## Design notes

- **Retrieval, not the model, is the hard part.** Chunking strategy matters more than which model answers the question — this repo splits on markdown headers first, so a chunk never straddles two unrelated sections, then sub-splits any still-long section into overlapping word windows. See `src/chunk_and_index.py`.
- **Why TF-IDF instead of a neural embedding model?** It keeps the whole project runnable instantly, offline, with no GPU and no download — a legitimate, classic retrieval baseline. Swapping in a sentence-transformer or an API-based embedding call is a one-function change (`chunk_and_index.py`), left as an intentional extension point rather than baked in, to keep the demo fast and dependency-light.
- **The log parser is a single compiled regex applied per line, streamed rather than loaded twice into memory** — this is what gets it to several hundred thousand lines/sec on a single core (see benchmark below), the same design principle that made the original internal decoder fast enough to use interactively instead of as a batch job.

## Benchmark (measured on this repo, reproducible via `demo/run_demo.py`)

```
Parsed 60,000 lines in 0.077–0.15s  (400K–775K lines/sec on a single core)
Errors: 4,830 (8.05%)
```

Run `python demo/run_demo.py` yourself to reproduce — numbers will vary slightly by machine, but the point is the order of magnitude: this is fast enough to decode a log while you're mid-debugging-session, not something you kick off and walk away from.

## Project structure

```
protocol-rag-bot/
├── data/
│   └── spec_docs/          # public, paraphrased MQTT protocol documentation
├── src/
│   ├── chunk_and_index.py  # chunking + TF-IDF index build
│   ├── query.py            # retrieval + optional LLM generation
│   ├── log_generator.py    # synthetic log generator
│   └── log_parser.py       # fast log decoder + summary stats
├── demo/
│   └── run_demo.py         # end-to-end demo, start to finish
├── tests/
│   └── test_basic.py
└── CIP_BOT_CASE_STUDY.md   # write-up of the original internal project
```

## Why this exists

This repo exists to demonstrate the same engineering pattern behind an internal tool I can't open-source, using data I'm free to share. The spec content is paraphrased from public MQTT documentation (not reproduced verbatim), and all log data is synthetically generated — nothing here is proprietary.
