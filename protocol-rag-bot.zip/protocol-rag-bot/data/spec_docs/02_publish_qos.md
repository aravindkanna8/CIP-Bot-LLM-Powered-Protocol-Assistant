# PUBLISH Packet and Quality of Service

A PUBLISH packet carries application data (the "payload") from a sender to the broker, and from the broker on to any subscribers. Each PUBLISH is associated with a Topic Name that determines which subscribers receive it.

## Quality of Service levels

- **QoS 0 — At most once**: the message is sent once with no acknowledgement and no retry. It may be lost if the connection drops mid-delivery. Cheapest in bandwidth and state, appropriate for high-frequency telemetry where an occasional dropped sample doesn't matter.
- **QoS 1 — At least once**: the sender keeps the message until it receives an acknowledgement (a PUBACK) from the recipient. If the acknowledgement doesn't arrive in time, the sender retransmits with a Duplicate flag set. This guarantees delivery but can result in the same message being delivered more than once, so receivers should be designed to tolerate duplicates.
- **QoS 2 — Exactly once**: uses a four-packet handshake (PUBLISH, PUBREC, PUBREL, PUBCOMP) so that both sides can guarantee the message is processed exactly one time, even across retransmissions. This is the most expensive QoS level in terms of round trips and state, and is reserved for cases where duplicate processing would be actively harmful (e.g., billing events).

## Retained messages

A PUBLISH may be marked "retained." The broker stores the most recent retained message for a topic and immediately delivers it to any client that subscribes to that topic afterward, even if the message was published before the subscription existed. Only one retained message is kept per topic; a new retained PUBLISH on the same topic replaces the old one. An empty payload with the retained flag set clears the retained message for that topic.

## Packet Identifiers

QoS 1 and QoS 2 messages carry a Packet Identifier so that acknowledgement packets can be matched back to the original PUBLISH. Packet Identifiers are scoped per-connection and must not be reused until the original exchange is complete, to avoid ambiguity when multiple in-flight messages are being acknowledged out of order.
