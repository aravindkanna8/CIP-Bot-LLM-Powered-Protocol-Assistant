# Session State and Reason Codes

## Session state

A session persists information between a client and broker across a single network connection, and — when Clean Start is not set — across multiple connections. Session state on the broker side can include: the set of active subscriptions, QoS 1 and QoS 2 messages that have been sent but not yet fully acknowledged, and QoS 1/2 messages queued for delivery while the client was disconnected.

Session state has a lifetime controlled by a Session Expiry Interval. Once a session expires, the broker discards all associated state, and a later connection with the same Client Identifier starts fresh regardless of the Clean Start flag.

## Reason codes

Most acknowledgement packets (CONNACK, PUBACK, SUBACK, DISCONNECT, and others) carry a one-byte Reason Code indicating the outcome of the operation. Reason codes are grouped roughly as:

- **0x00–0x7F**: successful or informational outcomes (e.g., "Success," "Granted QoS 1," "No matching subscribers").
- **0x80 and above**: error outcomes (e.g., "Unspecified error," "Malformed packet," "Not authorized," "Quota exceeded").

Distinguishing specific error reason codes (rather than collapsing everything into a generic failure) is what allows a client to decide intelligently whether to retry immediately, back off and retry later, or stop trying altogether — this is a recurring theme across most request/response protocols, not just this one.

## Keep Alive and connection loss detection

If a client has no data to send within its negotiated Keep Alive interval, it must send a lightweight PINGREQ to let the broker know it's still alive; the broker replies with PINGRESP. A broker that receives no packet at all from a client within one and a half times the Keep Alive interval should treat the network connection as lost, close it, and — if a Will Message was registered — publish it on the client's behalf.
