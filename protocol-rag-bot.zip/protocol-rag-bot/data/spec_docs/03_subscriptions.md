# Subscriptions and Topic Filters

A client subscribes to one or more Topic Filters via a SUBSCRIBE packet, and the broker responds with a SUBACK confirming, per filter, either the granted QoS level or a failure reason.

## Topic Filter wildcards

- **Single-level wildcard (`+`)**: matches exactly one topic level. For example, a filter of `sensors/+/temperature` matches `sensors/room1/temperature` and `sensors/room2/temperature`, but not `sensors/room1/hall/temperature`.
- **Multi-level wildcard (`#`)**: matches any number of trailing levels, and must be the last character in the filter. A filter of `sensors/#` matches `sensors/room1/temperature`, `sensors/room1`, and `sensors` itself.

A filter that contains a wildcard must not be used as a Topic Name on a PUBLISH — wildcards are only valid in filters used for subscribing, never in the topic a message is actually published to.

## Shared subscriptions

Multiple clients can subscribe to the same Topic Filter as part of a named group. The broker then load-balances matching messages across the group's members rather than delivering a copy to every member — useful for horizontally scaling consumers of a single logical topic without each consumer needing to track which messages it has already seen.

## Unsubscribing

An UNSUBSCRIBE packet removes one or more existing subscriptions. The broker should stop delivering new matching messages immediately after processing the UNSUBSCRIBE, though messages already in flight at the QoS handshake stage may still be completed.
