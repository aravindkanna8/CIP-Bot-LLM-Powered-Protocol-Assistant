# CONNECT Packet

The CONNECT packet is the first packet a client must send after opening a network connection to a broker. A broker that receives any other packet before a CONNECT packet must close the connection, and the client may only send one CONNECT packet per connection.

## Key fields

- **Protocol Name and Version**: identifies which version of the protocol the client speaks. A broker that does not support the requested version should refuse the connection with an appropriate reason code rather than silently downgrading.
- **Clean Start flag**: when set, the broker discards any existing session state for this client ID and starts fresh. When unset, the broker attempts to resume a previous session if one exists.
- **Keep Alive**: the maximum time interval, in seconds, that the client commits to between control packets. If the broker does not receive a packet (or a PINGREQ) within one and a half times this interval, it should treat the connection as lost and close it.
- **Client Identifier**: a string that uniquely identifies the client to the broker. If the client supplies an empty identifier, a broker that allows this must either generate one on the client's behalf or treat a Clean Start of zero as an error, depending on configuration.
- **Will Message (optional)**: a message the broker should publish automatically if the client disconnects unexpectedly (i.e., without a clean DISCONNECT packet). This lets other clients detect abnormal disconnection.
- **Username / Password (optional)**: credentials for authentication, independent of any transport-layer security.

## Common failure reasons

A broker may reject a CONNECT for several reasons, including: unsupported protocol version, client identifier rejected (e.g., malformed or already in use when the broker doesn't allow duplicate sessions), bad username or password, the client is not authorized, or the server is temporarily unavailable. Each rejection should carry a specific reason code so the client can decide whether to retry, back off, or give up.
